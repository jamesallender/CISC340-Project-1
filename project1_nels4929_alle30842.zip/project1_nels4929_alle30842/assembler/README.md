James Allender
Mitchell Nelson
CISC-340 
Project 01
README

assembler.c - This file is the C source code for our assembler

Makefile - This is a makefile to be used with Make to build our project

Test Files:
	Demonstrating functionality:
	test1.txt - tests the assembler with a loop, lw using a label, comments, and jalr
	test2.txt - tests the assembler with all instuction types. Uses the biggest and smallest possible immediate values
	test3.txt - tests the assembler with both tabs and spaces as well as using an immediate value that is not on the first line
	test4.txt - tests the assembler with extra white space on the front of an instruction
	test5.txt - test case given from Dr. Myre. Tests loops, label, several instruction types
	test6.txt - check for functyonality of a lable in a non immidiate field

	Demonstrating error checking:
	test7.txt - tests the assembler to ensure a missing instruction param is caught
	test8.txt - tests a valid label that has no corresponding value
	test9.txt - tests an invalid label that starts with a number
	test10.txt - tests a label that is too long
	test11.txt - tests an invalid label with an "@"
	test12.txt - tests an invalid label that starts with "#"
	test13.txt - tests for exmpty parameters on instructions
	test14.txt - tests for invalid registers
	test15.txt - test for handeling empty line
	test16.txt - test handeling file contaning only empty white space
	test17.txt - test handeling empty file
